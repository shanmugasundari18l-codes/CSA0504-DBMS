# Netflix Catalogue DBMS (Team 5 capstone)

Flask + MySQL 8 web application: Dataset Manager, Database Explorer, Normalization,
ER Diagram, SQL Query Explorer, 10 SQL Reports (export PDF/Excel/CSV), Dashboard (10 charts), Manage Data (CRUD).

## Quick start
1. Install Python 3.10+ and MySQL 8. Start MySQL.
2. Download `netflix_titles.csv` from https://www.kaggle.com/datasets/shivamb/netflix-shows and put it in `data/`.
3. Edit `config.py` -> set your MySQL password (or set env var DB_PASSWORD).
4. `pip install -r requirements.txt`
5. `python import_data.py data/netflix_titles.csv`
6. `python app.py`  -> open http://127.0.0.1:5000

`data/SYNTHETIC_smoke_test.csv` is a tiny FAKE file (120 invented rows) only for checking that the
pipeline runs. Never use it in your report - the project must use the real Kaggle data.

Files: schema.sql (DDL, views, indexes) | etl.py + import_data.py (clean + load) | reports.py (10 reports)
| queries.sql (all report SQL) | app.py (pages) | er.py (ER diagram) | templates/ static/
