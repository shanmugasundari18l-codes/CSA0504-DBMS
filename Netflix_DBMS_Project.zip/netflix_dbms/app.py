"""Netflix Catalogue DBMS - Flask web application.   Run:  python app.py"""
import csv
import io
import os
import re
import time
from flask import (Flask, Response, flash, jsonify, redirect, render_template,
                   request, send_file, url_for)
from werkzeug.utils import secure_filename

import db
import er
import etl
import reports
from config import SECRET_KEY, UPLOAD_DIR, DB_NAME

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024
os.makedirs(UPLOAD_DIR, exist_ok=True)

DATA_DICTIONARY = [  # (CSV column, staging column, type, meaning)
    ("show_id", "show_id", "Text (unique key)", "Unique ID of the title (s1, s2, ...)"),
    ("type", "type", "Text (category)", "Movie or TV Show"),
    ("title", "title", "Text", "Name of the movie / TV show"),
    ("director", "director", "Text (multi-valued)", "Director name(s), comma separated"),
    ("cast", "cast_members", "Text (multi-valued)", "Cast members, comma separated"),
    ("country", "country", "Text (multi-valued)", "Production country/countries, comma separated"),
    ("date_added", "date_added", "Date stored as text", "Date the title was added to Netflix, e.g. September 25, 2021"),
    ("release_year", "release_year", "Integer (year)", "Original release year"),
    ("rating", "rating", "Text (category)", "Maturity rating such as TV-MA or PG-13"),
    ("duration", "duration", "Text", "Minutes for movies, number of seasons for TV shows"),
    ("listed_in", "listed_in", "Text (multi-valued)", "Genres / categories, comma separated"),
    ("description", "description", "Long text", "Short plot summary"),
]
CORE_TABLES = ["content_type", "rating", "titles", "country", "genre", "person",
               "title_country", "title_genre", "title_director", "title_cast"]


# ----------------------------------------------------------- helpers
def page_args(extra=None):
    a = {k: v for k, v in request.args.items() if k != "page"}
    if extra:
        a.update(extra)
    return a


def filter_args():
    return {k: request.args.get(k, "") for k in reports.FILTER_FIELDS}


def filter_options():
    return {
        "types": [r["type_name"] for r in db.query("SELECT type_name FROM content_type ORDER BY type_name")],
        "ratings": [r["rating_code"] for r in db.query("SELECT rating_code FROM rating ORDER BY rating_code")],
        "countries": [r["country_name"] for r in db.query("SELECT country_name FROM country ORDER BY country_name")],
        "genres": [r["genre_name"] for r in db.query("SELECT genre_name FROM genre ORDER BY genre_name")],
    }


def run_report(spec, args):
    sql, params = reports.render(spec, args)
    cols, rows, _ = db.query_table(sql, params)
    return cols, rows


@app.errorhandler(Exception)
def handle_error(e):
    code = getattr(e, "code", 500)
    if isinstance(code, int) and code < 500:
        return e
    return render_template("error.html", message=str(e)), 500


# ----------------------------------------------------------- dashboard
@app.route("/")
def dashboard():
    kpi = db.query(reports.KPI_SQL)[0]
    return render_template("dashboard.html", kpi=kpi, charts=reports.DASHBOARD,
                           opts=filter_options(), f=filter_args())


@app.route("/api/chart/<key>")
def api_chart(key):
    item = next((d for d in reports.DASHBOARD if d[0] == key), None)
    if not item:
        return jsonify(error="unknown chart"), 404
    spec = reports.get_report(item[3]) if isinstance(item[3], int) else reports.EXTRA[item[3]]
    cols, rows = run_report(spec, filter_args())
    idx = cols.index(spec["label"])
    labels = [str(r[idx]) for r in rows]
    datasets = [{"label": v.replace("_", " ").title(), "data": [r[cols.index(v)] for r in rows]}
                for v in spec["values"]]
    return jsonify(labels=labels, datasets=datasets)


# ----------------------------------------------------------- dataset manager
@app.route("/dataset")
def dataset():
    info = db.query("SELECT * FROM dataset_info WHERE info_id = 1")
    log = db.query("SELECT * FROM import_log ORDER BY import_id DESC LIMIT 1")
    log = log[0] if log else None
    total = db.query("SELECT COUNT(*) AS n FROM staging_netflix")[0]["n"]
    miss_sql = "SELECT " + ", ".join(
        "SUM(`%s` IS NULL OR TRIM(`%s`) = '') AS `%s`" % (s, s, s) for _, s, _, _ in DATA_DICTIONARY
    ) + " FROM staging_netflix"
    miss = db.query(miss_sql)[0]
    dictionary = []
    for csv_col, s, typ, meaning in DATA_DICTIONARY:
        ex = db.query("SELECT DISTINCT LEFT(`%s`, 40) AS v FROM staging_netflix "
                      "WHERE `%s` IS NOT NULL AND TRIM(`%s`) <> '' LIMIT 3" % (s, s, s))
        m = int(miss[s] or 0)
        dictionary.append(dict(name=csv_col, type=typ, meaning=meaning, missing=m,
                               pct=round(100.0 * m / total, 1) if total else 0,
                               examples=" | ".join(e["v"] for e in ex)))
    issues = db.query("SELECT issue_type, COUNT(*) AS n FROM import_issue "
                      "WHERE import_id = %s GROUP BY issue_type ORDER BY n DESC",
                      (log["import_id"],)) if log else []
    issue_rows = db.query("SELECT row_no, show_id, column_name, issue_type, issue_detail FROM import_issue "
                          "WHERE import_id = %s ORDER BY issue_id LIMIT 50", (log["import_id"],)) if log else []
    a = request.args
    prev = db.browse("staging_netflix", int(a.get("page", 1) or 1), 10, a.get("q", ""),
                     a.get("sort", ""), a.get("dir", "asc"))
    return render_template("dataset.html", info=info[0] if info else {}, log=log, total=total,
                           ncols=len(DATA_DICTIONARY), dictionary=dictionary, issues=issues,
                           issue_rows=issue_rows, prev=prev, args=page_args(), q=a.get("q", ""),
                           sort=a.get("sort", ""), dir=a.get("dir", "asc"))


@app.route("/dataset/url", methods=["POST"])
def dataset_url():
    url = request.form.get("source_url", "").strip()[:500]
    db.execute("UPDATE dataset_info SET source_url = %s WHERE info_id = 1", (url,))
    flash("Dataset source URL saved.", "success")
    return redirect(url_for("dataset"))


@app.route("/dataset/import", methods=["POST"])
def dataset_import():
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose a CSV or Excel file first.", "danger")
        return redirect(url_for("dataset"))
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in (".csv", ".xlsx", ".xls"):
        flash("Only .csv, .xlsx or .xls files are allowed.", "danger")
        return redirect(url_for("dataset"))
    path = os.path.join(UPLOAD_DIR, secure_filename(f.filename))
    f.save(path)
    try:
        s = etl.run_import(path, request.form.get("source_url") or None)
        flash("Import finished: %(rows_read)s rows read, %(rows_loaded)s loaded, "
              "%(duplicate_key_rows)s duplicate keys, %(error_rows)s rejected, %(issues)s issues logged." % s, "success")
    except Exception as e:
        flash("Import failed: %s" % e, "danger")
    return redirect(url_for("dataset"))


# ----------------------------------------------------------- database explorer
def table_detail(table):
    cols = db.query(
        "SELECT COLUMN_NAME AS column_name, COLUMN_TYPE AS column_type, IS_NULLABLE AS is_nullable, "
        "COLUMN_KEY AS column_key, COLUMN_DEFAULT AS column_default, EXTRA AS extra "
        "FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s "
        "ORDER BY ORDINAL_POSITION", (table,))
    cons = db.query(
        "SELECT tc.CONSTRAINT_NAME AS constraint_name, tc.CONSTRAINT_TYPE AS constraint_type, "
        "GROUP_CONCAT(k.COLUMN_NAME ORDER BY k.ORDINAL_POSITION) AS cols, "
        "MAX(k.REFERENCED_TABLE_NAME) AS ref_table, "
        "GROUP_CONCAT(k.REFERENCED_COLUMN_NAME ORDER BY k.ORDINAL_POSITION) AS ref_cols "
        "FROM information_schema.TABLE_CONSTRAINTS tc "
        "LEFT JOIN information_schema.KEY_COLUMN_USAGE k ON k.CONSTRAINT_SCHEMA = tc.CONSTRAINT_SCHEMA "
        "AND k.TABLE_NAME = tc.TABLE_NAME AND k.CONSTRAINT_NAME = tc.CONSTRAINT_NAME "
        "WHERE tc.TABLE_SCHEMA = DATABASE() AND tc.TABLE_NAME = %s "
        "GROUP BY tc.CONSTRAINT_NAME, tc.CONSTRAINT_TYPE ORDER BY tc.CONSTRAINT_TYPE", (table,))
    checks = {r["constraint_name"]: r["check_clause"] for r in db.query(
        "SELECT CONSTRAINT_NAME AS constraint_name, CHECK_CLAUSE AS check_clause "
        "FROM information_schema.CHECK_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE()")}
    for c in cons:
        c["check_clause"] = checks.get(c["constraint_name"], "")
    badge = {}
    for c in cons:
        tag = {"PRIMARY KEY": "PK", "FOREIGN KEY": "FK", "UNIQUE": "UK"}.get(c["constraint_type"])
        for col in (c["cols"] or "").split(","):
            if tag and col:
                badge.setdefault(col, [])
                if tag not in badge[col]:
                    badge[col].append(tag)
    for c in cols:
        c["badges"] = badge.get(c["column_name"], [])
    return cols, cons


@app.route("/explorer")
@app.route("/explorer/<table>")
def explorer(table=None):
    tables = db.list_tables()
    for t in tables:
        t["rows"] = db.query("SELECT COUNT(*) AS n FROM `%s`" % t["table_name"])[0]["n"]
    rels = db.query(
        "SELECT TABLE_NAME AS child_table, COLUMN_NAME AS child_column, "
        "REFERENCED_TABLE_NAME AS parent_table, REFERENCED_COLUMN_NAME AS parent_column, "
        "CONSTRAINT_NAME AS constraint_name FROM information_schema.KEY_COLUMN_USAGE "
        "WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME IS NOT NULL "
        "ORDER BY TABLE_NAME, CONSTRAINT_NAME")
    ctx = dict(dbname=DB_NAME, tables=tables, rels=rels, table=table, cols=None, cons=None, data=None)
    if table:
        if table not in [t["table_name"] for t in tables]:
            flash("Unknown table.", "danger")
            return redirect(url_for("explorer"))
        a = request.args
        ctx["cols"], ctx["cons"] = table_detail(table)
        ctx["data"] = db.browse(table, int(a.get("page", 1) or 1), int(a.get("per", 15) or 15),
                                a.get("q", ""), a.get("sort", ""), a.get("dir", "asc"),
                                a.get("fcol", ""), a.get("fval", ""))
        ctx.update(args=page_args({"table": table}), a=a)
    return render_template("explorer.html", **ctx)


# ----------------------------------------------------------- normalization
NORM_CHECKS = [
    ("Rows in the raw (staging) table", "SELECT COUNT(*) AS value FROM staging_netflix"),
    ("Distinct show_id values", "SELECT COUNT(DISTINCT show_id) AS value FROM staging_netflix"),
    ("show_id values that repeat (would break the key)",
     "SELECT COUNT(*) AS value FROM (SELECT show_id FROM staging_netflix GROUP BY show_id HAVING COUNT(*) > 1) x"),
    ("(title, type, release_year) combinations that repeat",
     "SELECT COUNT(*) AS value FROM (SELECT 1 FROM staging_netflix GROUP BY title, `type`, release_year HAVING COUNT(*) > 1) x"),
    ("Rows with 2+ genres in one cell (listed_in)", "SELECT COUNT(*) AS value FROM staging_netflix WHERE listed_in LIKE '%,%'"),
    ("Rows with 2+ countries in one cell", "SELECT COUNT(*) AS value FROM staging_netflix WHERE country LIKE '%,%'"),
    ("Rows with 2+ directors in one cell", "SELECT COUNT(*) AS value FROM staging_netflix WHERE director LIKE '%,%'"),
    ("Rows with 2+ cast members in one cell", "SELECT COUNT(*) AS value FROM staging_netflix WHERE cast_members LIKE '%,%'"),
]
UNIT_SQL = ("SELECT `type`, GROUP_CONCAT(DISTINCT TRIM(REGEXP_REPLACE(duration, '[0-9]+', ''))) AS duration_units, "
            "COUNT(*) AS rows_checked FROM staging_netflix WHERE duration IS NOT NULL AND duration <> '' "
            "GROUP BY `type`")


@app.route("/normalization")
def normalization():
    stage_cols, _ = table_detail("staging_netflix")
    sample = db.query("SELECT show_id, `type`, title, director, country, date_added, rating, duration, listed_in "
                      "FROM staging_netflix ORDER BY row_no LIMIT 3")
    checks = [(label, db.query(sql)[0]["value"]) for label, sql in NORM_CHECKS]
    units = db.query(UNIT_SQL)
    final = []
    for t in CORE_TABLES:
        cols, cons = table_detail(t)
        final.append(dict(name=t, cols=cols, cons=cons))
    return render_template("normalization.html", stage_cols=stage_cols, sample=sample,
                           checks=checks, units=units, final=final)


# ----------------------------------------------------------- ER diagram
@app.route("/er")
def er_page():
    return render_template("er.html", svg=er.build_svg())


@app.route("/er.svg")
def er_svg():
    return Response(er.build_svg(), mimetype="image/svg+xml",
                    headers={"Content-Disposition": "attachment; filename=er_diagram.svg"})


# ----------------------------------------------------------- SQL query explorer
SQL_SAMPLES = {
    "JOIN + GROUP BY": "SELECT ct.type_name, COUNT(*) AS total\nFROM titles t\nJOIN content_type ct ON ct.type_id = t.type_id\nGROUP BY ct.type_name;",
    "Subquery": "SELECT title, release_year\nFROM titles\nWHERE release_year < (SELECT AVG(release_year) FROM titles)\nORDER BY release_year\nLIMIT 20;",
    "Window function": "SELECT c.country_name, COUNT(*) AS n,\n       RANK() OVER (ORDER BY COUNT(*) DESC) AS rnk\nFROM title_country tc\nJOIN country c ON c.country_id = tc.country_id\nGROUP BY c.country_name\nLIMIT 10;",
    "View": "SELECT * FROM vw_title_details LIMIT 20;",
    "EXPLAIN plan": "EXPLAIN SELECT c.country_name, COUNT(DISTINCT t.show_id)\nFROM titles t\nJOIN title_country tc ON tc.show_id = t.show_id\nJOIN country c ON c.country_id = tc.country_id\nGROUP BY c.country_id, c.country_name;",
}
ALLOWED_START = ("select", "with", "show", "describe", "desc", "explain")


@app.route("/sql", methods=["GET", "POST"])
def sql_editor():
    sql = request.form.get("sql", SQL_SAMPLES["JOIN + GROUP BY"])
    result = None
    if request.method == "POST":
        text = sql.strip().rstrip(";").strip()
        result = {"error": None, "cols": [], "rows": [], "truncated": False, "ms": 0}
        if not text:
            result["error"] = "Type a query first."
        elif ";" in text:
            result["error"] = "Run one statement at a time (remove the extra semicolon)."
        elif not text.lower().startswith(ALLOWED_START):
            result["error"] = "Read-only editor: start with SELECT, WITH, SHOW, DESCRIBE or EXPLAIN."
        else:
            t0 = time.time()
            try:
                result["cols"], result["rows"], result["truncated"] = db.query_table(
                    text, readonly=True, timeout_ms=10000, limit=1000)
            except Exception as e:
                result["error"] = str(e)
            result["ms"] = round((time.time() - t0) * 1000)
    return render_template("sql.html", sql=sql, result=result, samples=SQL_SAMPLES)


# ----------------------------------------------------------- reports
@app.route("/reports")
def report_list():
    return render_template("report_list.html", reports=reports.REPORTS)


@app.route("/reports/<int:rid>")
def report_view(rid):
    spec = reports.get_report(rid)
    if not spec:
        return redirect(url_for("report_list"))
    cols, rows = run_report(spec, filter_args())
    sql, _ = reports.render(spec, filter_args())
    return render_template("report.html", r=spec, cols=cols, rows=rows, opts=filter_options(),
                           f=filter_args(), sql=sql, qs=request.query_string.decode())


def slug(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


@app.route("/reports/<int:rid>/export/<fmt>")
def report_export(rid, fmt):
    spec = reports.get_report(rid)
    if not spec or fmt not in ("csv", "xlsx", "pdf"):
        return redirect(url_for("report_list"))
    cols, rows = run_report(spec, filter_args())
    name = "report_%d_%s" % (rid, slug(spec["name"]))
    if fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(cols)
        w.writerows(rows)
        return Response("\ufeff" + buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=%s.csv" % name})
    if fmt == "xlsx":
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Report %d" % rid
        ws.append(cols)
        for r in rows:
            ws.append(r)
        bio = io.BytesIO()
        wb.save(bio)
        bio.seek(0)
        return send_file(bio, as_attachment=True, download_name=name + ".xlsx",
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    bio = io.BytesIO()
    doc = SimpleDocTemplate(bio, pagesize=landscape(A4), leftMargin=24, rightMargin=24, topMargin=24, bottomMargin=24)
    st = getSampleStyleSheet()
    data = [cols] + [[str(v)[:60] if v is not None else "" for v in r] for r in rows]
    tbl = Table(data, repeatRows=1)
    tbl.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#b20710")),
                             ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                             ("FONTSIZE", (0, 0), (-1, -1), 8),
                             ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
                             ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")])]))
    doc.build([Paragraph("Report %d - %s" % (rid, spec["name"]), st["Title"]),
               Paragraph("Technique: " + spec["technique"], st["Normal"]), Spacer(1, 10), tbl])
    bio.seek(0)
    return send_file(bio, as_attachment=True, download_name=name + ".pdf", mimetype="application/pdf")


# ----------------------------------------------------------- manage (CRUD)
@app.route("/manage")
def manage():
    q = request.args.get("q", "")
    rows = db.query(
        "SELECT t.show_id, t.title, ct.type_name AS content_type, t.release_year, r.rating_code AS rating "
        "FROM titles t JOIN content_type ct ON ct.type_id = t.type_id "
        "LEFT JOIN rating r ON r.rating_id = t.rating_id "
        "WHERE t.title LIKE %s ORDER BY (t.show_id LIKE 'u%%') DESC, t.show_id LIMIT 25", ("%" + q + "%",))
    return render_template("manage.html", rows=rows, q=q, opts=filter_options())


@app.route("/manage/add", methods=["POST"])
def manage_add():
    f = request.form
    title, typ = f.get("title", "").strip(), f.get("type", "")
    year = f.get("release_year", "")
    if not title or not year.isdigit() or not typ:
        flash("Title, type and a numeric release year are required.", "danger")
        return redirect(url_for("manage"))
    nxt = db.query("SELECT COALESCE(MAX(CAST(SUBSTRING(show_id, 2) AS UNSIGNED)), 0) + 1 AS n "
                   "FROM titles WHERE show_id LIKE 'u%'")[0]["n"]
    sid = "u%d" % nxt   # 'u' = user-added, never mixed up with the original s1..s8807
    db.execute("INSERT INTO titles (show_id, type_id, title, release_year, rating_id) VALUES "
               "(%s, (SELECT type_id FROM content_type WHERE type_name = %s), %s, %s, "
               "(SELECT rating_id FROM rating WHERE rating_code = %s))",
               (sid, typ, title, int(year), f.get("rating") or None))
    flash("Added %s (%s)." % (title, sid), "success")
    return redirect(url_for("manage"))


@app.route("/manage/<sid>/update", methods=["POST"])
def manage_update(sid):
    year = request.form.get("release_year", "")
    if not year.isdigit():
        flash("Release year must be a number.", "danger")
    else:
        db.execute("UPDATE titles SET title = %s, release_year = %s WHERE show_id = %s",
                   (request.form.get("title", "").strip(), int(year), sid))
        flash("Updated %s." % sid, "success")
    return redirect(url_for("manage"))


@app.route("/manage/<sid>/delete", methods=["POST"])
def manage_delete(sid):
    db.execute("DELETE FROM titles WHERE show_id = %s", (sid,))   # bridge rows go with it (ON DELETE CASCADE)
    flash("Deleted %s." % sid, "warning")
    return redirect(url_for("manage"))


if __name__ == "__main__":
    app.run(debug=True)
