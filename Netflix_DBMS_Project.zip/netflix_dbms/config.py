"""Project settings. Change DB_PASSWORD to YOUR MySQL root password
(or set it as an environment variable so it never goes into GitHub)."""
import os

DB = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "your_password_here"),
}
DB_NAME = os.getenv("DB_NAME", "netflix_dbms")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
SCHEMA_FILE = os.path.join(BASE_DIR, "schema.sql")
DEFAULT_CSV = os.path.join(BASE_DIR, "data", "netflix_titles.csv")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret")
