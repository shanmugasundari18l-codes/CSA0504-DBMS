"""Tiny database helper used by every page."""
import datetime
import decimal
import mysql.connector
from config import DB, DB_NAME


def connect(database=True):
    cfg = dict(DB)
    if database:
        cfg["database"] = DB_NAME
    return mysql.connector.connect(charset="utf8mb4", autocommit=True, **cfg)


def jsonable(v):
    if isinstance(v, decimal.Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return bytes(v).decode("utf-8", "replace")
    if isinstance(v, (set, datetime.timedelta)):
        return str(v)
    return v


def query(sql, params=None):
    """Run a SELECT and return a list of dicts."""
    conn = connect()
    try:
        cur = conn.cursor(dictionary=True, buffered=True)
        cur.execute(sql, params or None)
        rows = cur.fetchall() if cur.with_rows else []
        return [{k: jsonable(v) for k, v in r.items()} for r in rows]
    finally:
        conn.close()


def query_table(sql, params=None, readonly=False, timeout_ms=None, limit=None):
    """Run a SELECT and return (columns, rows, truncated). Rows are lists."""
    conn = connect()
    try:
        cur = conn.cursor(buffered=True)
        if readonly:
            cur.execute("SET SESSION TRANSACTION READ ONLY")
        if timeout_ms:
            cur.execute("SET SESSION MAX_EXECUTION_TIME=%d" % int(timeout_ms))
        cur.execute(sql, params or None)
        if not cur.with_rows:
            return [], [], False
        cols = list(cur.column_names)
        rows = cur.fetchmany(limit + 1) if limit else cur.fetchall()
        truncated = bool(limit) and len(rows) > limit
        if truncated:
            rows = rows[:limit]
        return cols, [[jsonable(v) for v in r] for r in rows], truncated
    finally:
        conn.close()


def execute(sql, params=None):
    """Run INSERT/UPDATE/DELETE. Returns (rowcount, lastrowid)."""
    conn = connect()
    try:
        cur = conn.cursor()
        cur.execute(sql, params or None)
        return cur.rowcount, cur.lastrowid
    finally:
        conn.close()


# ---------- metadata helpers (information_schema) ----------
def list_tables():
    return query(
        "SELECT TABLE_NAME AS table_name, TABLE_TYPE AS table_type "
        "FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() "
        "ORDER BY TABLE_TYPE, TABLE_NAME")


def table_columns(table):
    return [r["column_name"] for r in query(
        "SELECT COLUMN_NAME AS column_name FROM information_schema.COLUMNS "
        "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s ORDER BY ORDINAL_POSITION",
        (table,))]


def browse(table, page=1, per_page=15, q="", sort="", direction="asc", fcol="", fval=""):
    """Search / filter / sort / paginate ANY table (names are whitelisted)."""
    cols = table_columns(table)
    if not cols:
        raise ValueError("Unknown table")
    where, params = [], []
    if q:
        concat = ", ".join("`%s`" % c for c in cols)
        where.append("CONCAT_WS(' ', %s) LIKE %%s" % concat)
        params.append("%" + q + "%")
    if fcol in cols and fval != "":
        where.append("CAST(`%s` AS CHAR) LIKE %%s" % fcol)
        params.append("%" + fval + "%")
    wsql = (" WHERE " + " AND ".join(where)) if where else ""
    total = query("SELECT COUNT(*) AS n FROM `%s`%s" % (table, wsql), params)[0]["n"]
    pages = max(1, -(-total // per_page))
    page = min(max(1, page), pages)
    order = ""
    if sort in cols:
        order = " ORDER BY `%s` %s" % (sort, "DESC" if direction == "desc" else "ASC")
    sql = "SELECT * FROM `%s`%s%s LIMIT %d OFFSET %d" % (
        table, wsql, order, per_page, (page - 1) * per_page)
    return {"columns": cols, "rows": query(sql, params), "total": total,
            "page": page, "pages": pages, "per_page": per_page}
