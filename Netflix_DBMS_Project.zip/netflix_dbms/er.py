"""Draws the ER diagram of the final database as a plain SVG (no JavaScript needed),
so it can be zoomed, downloaded as SVG, and exported to PNG/PDF from the browser."""
from xml.sax.saxutils import escape

W = 250          # box width
HEAD, ROW = 30, 22

# name: (x, y, header colour, [(attribute, key)])   key: PK / FK / UK / PK,FK / ""
ENT = {
 "content_type": (40, 60, "#6c757d", [("type_id", "PK"), ("type_name", "UK"), ("duration_unit", "")]),
 "rating":       (40, 330, "#6c757d", [("rating_id", "PK"), ("rating_code", "UK")]),
 "titles":       (470, 150, "#b20710", [("show_id", "PK"), ("type_id", "FK"), ("title", ""),
                  ("date_added", ""), ("release_year", ""), ("rating_id", "FK"),
                  ("duration_value", ""), ("description", "")]),
 "title_country":  (870, 30, "#5a4b9a", [("show_id", "PK,FK"), ("country_id", "PK,FK")]),
 "country":        (1200, 30, "#6c757d", [("country_id", "PK"), ("country_name", "UK")]),
 "title_genre":    (870, 180, "#5a4b9a", [("show_id", "PK,FK"), ("genre_id", "PK,FK")]),
 "genre":          (1200, 180, "#6c757d", [("genre_id", "PK"), ("genre_name", "UK")]),
 "title_director": (870, 340, "#5a4b9a", [("show_id", "PK,FK"), ("person_id", "PK,FK")]),
 "person":         (1200, 410, "#6c757d", [("person_id", "PK"), ("person_name", "UK")]),
 "title_cast":     (870, 500, "#5a4b9a", [("show_id", "PK,FK"), ("person_id", "PK,FK")]),
 "import_log":   (40, 650, "#2b6cb0", [("import_id", "PK"), ("file_name", ""), ("file_size_kb", ""),
                  ("imported_at", ""), ("rows_read", ""), ("rows_loaded", ""), ("error_rows", "")]),
 "import_issue": (400, 650, "#2b6cb0", [("issue_id", "PK"), ("import_id", "FK"), ("row_no", ""),
                  ("show_id", ""), ("column_name", ""), ("issue_type", ""), ("issue_detail", "")]),
}

# parent, parent_col, child, child_col, parent label, child label, elbow x (None=auto)
RELS = [
 ("content_type", "type_id", "titles", "type_id", "1", "N", 330),
 ("rating", "rating_id", "titles", "rating_id", "1", "N", 400),
 ("titles", "show_id", "title_country", "show_id", "1", "N", 790),
 ("titles", "show_id", "title_genre", "show_id", "1", "N", 810),
 ("titles", "show_id", "title_director", "show_id", "1", "N", 830),
 ("titles", "show_id", "title_cast", "show_id", "1", "N", 850),
 ("country", "country_id", "title_country", "country_id", "1", "N", 1160),
 ("genre", "genre_id", "title_genre", "genre_id", "1", "N", 1160),
 ("person", "person_id", "title_director", "person_id", "1", "N", 1170),
 ("person", "person_id", "title_cast", "person_id", "1", "N", 1180),
 ("import_log", "import_id", "import_issue", "import_id", "1", "N", None),
]

KEYCOL = {"PK": "#d69e2e", "FK": "#2b6cb0", "UK": "#38a169"}


def _h(name):
    return HEAD + ROW * len(ENT[name][3]) + 6


def _row_y(name, col):
    attrs = ENT[name][3]
    i = [a for a, _ in attrs].index(col)
    return ENT[name][1] + HEAD + ROW * i + ROW / 2


def _box(name):
    x, y, colour, attrs = ENT[name]
    out = ['<g>',
           '<rect x="%d" y="%d" width="%d" height="%d" rx="6" fill="#ffffff" stroke="%s" stroke-width="2"/>'
           % (x, y, W, _h(name), colour),
           '<rect x="%d" y="%d" width="%d" height="%d" rx="6" fill="%s"/>' % (x, y, W, HEAD, colour),
           '<text x="%d" y="%d" fill="#ffffff" font-family="Arial, sans-serif" font-size="14" '
           'font-weight="bold" text-anchor="middle">%s</text>' % (x + W / 2, y + 20, escape(name))]
    for i, (a, k) in enumerate(attrs):
        ty = y + HEAD + ROW * i + 16
        if k:
            first = k.split(",")[0]
            out.append('<text x="%d" y="%d" font-family="Arial, sans-serif" font-size="11" font-weight="bold" '
                       'fill="%s">%s</text>' % (x + 8, ty, KEYCOL[first], escape(k)))
        weight = "bold" if "PK" in k else "normal"
        out.append('<text x="%d" y="%d" font-family="Arial, sans-serif" font-size="13" font-weight="%s" '
                   'fill="#1a202c">%s</text>' % (x + 62, ty, weight, escape(a)))
    out.append("</g>")
    return "\n".join(out)


def _rel(p, pc, c, cc, pl, cl, mid):
    px, cx = ENT[p][0], ENT[c][0]
    py, cy = _row_y(p, pc), _row_y(c, cc)
    if px + W < cx:                       # parent on the left
        x1, x2, d1, d2 = px + W, cx, 1, -1
    elif cx + W < px:                     # parent on the right
        x1, x2, d1, d2 = px, cx + W, -1, 1
    else:                                 # same column: go parent bottom -> child top
        x1 = x2 = px + W / 2
        y1, y2 = ENT[p][1] + _h(p), ENT[c][1]
        return ('<path d="M%d %d L%d %d" stroke="#4a5568" stroke-width="1.6" fill="none"/>'
                '<text x="%d" y="%d" font-size="13" font-weight="bold" font-family="Arial, sans-serif" fill="#c53030">%s</text>'
                '<text x="%d" y="%d" font-size="13" font-weight="bold" font-family="Arial, sans-serif" fill="#c53030">%s</text>'
                % (x1, y1, x2, y2, x1 + 8, y1 + 16, pl, x2 + 8, y2 - 6, cl))
    m = mid if mid else (x1 + x2) / 2
    path = "M%d %d L%d %d L%d %d L%d %d" % (x1, py, m, py, m, cy, x2, cy)
    return ('<path d="%s" stroke="#4a5568" stroke-width="1.6" fill="none"/>'
            '<text x="%d" y="%d" font-size="13" font-weight="bold" font-family="Arial, sans-serif" fill="#c53030" text-anchor="%s">%s</text>'
            '<text x="%d" y="%d" font-size="13" font-weight="bold" font-family="Arial, sans-serif" fill="#c53030" text-anchor="%s">%s</text>'
            % (path, x1 + 6 * d1, py - 5, "start" if d1 == 1 else "end", pl,
               x2 + 6 * d2, cy - 5, "start" if d2 == 1 else "end", cl))


def build_svg():
    width, height = 1490, 900
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" id="erSvg" width="%d" height="%d" '
             'viewBox="0 0 %d %d">' % (width, height, width, height),
             '<rect width="100%" height="100%" fill="#ffffff"/>']
    parts += [_rel(*r) for r in RELS]
    parts += [_box(n) for n in ENT]
    leg = [("PK", "Primary key"), ("FK", "Foreign key"), ("UK", "Unique key")]
    for i, (k, t) in enumerate(leg):
        parts.append('<text x="%d" y="760" font-family="Arial, sans-serif" font-size="12" font-weight="bold" '
                     'fill="%s">%s</text><text x="%d" y="760" font-family="Arial, sans-serif" font-size="12" '
                     'fill="#1a202c">= %s</text>' % (800 + i * 150, KEYCOL[k], k, 822 + i * 150, t))
    notes = ["Cardinality: 1 = one, N = many (1:N).  titles-country, titles-genre, titles-director, titles-cast are M:N,",
             "resolved with bridge tables (purple).  Grey = lookup tables.  Blue = import audit tables.",
             "staging_netflix (raw CSV copy) and dataset_info (metadata) have no relationships and are not drawn."]
    for i, n in enumerate(notes):
        parts.append('<text x="800" y="%d" font-family="Arial, sans-serif" font-size="12" fill="#4a5568">%s</text>'
                     % (790 + i * 18, escape(n)))
    parts.append('<text x="40" y="30" font-family="Arial, sans-serif" font-size="18" font-weight="bold" '
                 'fill="#1a202c">ER Diagram - Netflix Catalogue Database (3NF)</text>')
    parts.append("</svg>")
    return "\n".join(parts)
