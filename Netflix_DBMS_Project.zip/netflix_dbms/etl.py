"""CSV/Excel -> staging -> normalized tables.
clean_dataset() is pure pandas (no database) so it can be tested alone."""
import os
import re
import pandas as pd
from config import DB_NAME, SCHEMA_FILE
from db import connect

RAW_COLS = ["show_id", "type", "title", "director", "cast", "country",
            "date_added", "release_year", "rating", "duration",
            "listed_in", "description"]
VALID_TYPES = {"Movie": "min", "TV Show": "Season(s)"}
DUR_PATTERN = r"^(\d+)\s*(min|seasons?)$"


# ------------------------------------------------------------------ read
def read_dataset(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        df = pd.read_excel(path, dtype=str)
    else:
        df = pd.read_csv(path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    df = df.fillna("")
    df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in RAW_COLS if c not in df.columns]
    if missing:
        raise ValueError("File is missing expected columns: " + ", ".join(missing))
    df = df[RAW_COLS].copy()
    for c in RAW_COLS:
        df[c] = df[c].astype(str).str.strip()
    return df


# ----------------------------------------------------------------- clean
def split_multi(ids, values):
    """'A, B, C' -> [(id,'A'), (id,'B'), (id,'C')] (no empties, no repeats per title)."""
    pairs = []
    for sid, val in zip(ids, values):
        seen = set()
        for part in val.split(","):
            p = part.strip()
            if p and p not in seen:
                seen.add(p)
                pairs.append((sid, p))
    return pairs


def clean_dataset(df):
    issues = []

    def add(row_no, show_id, col, kind, detail):
        issues.append((int(row_no), show_id or None, col, kind, detail[:250]))

    def reject(frame, mask, col, kind, detail):
        for r in frame[mask].itertuples(index=False):
            add(r.row_no, r.show_id, col, kind, detail)
        return frame[~mask]

    df = df.reset_index(drop=True).copy()
    df.insert(0, "row_no", range(1, len(df) + 1))
    summary = {"rows_read": len(df)}
    summary["duplicate_full_rows"] = int(
        df.drop(columns="row_no").duplicated(keep="first").sum())

    work = reject(df, df["show_id"] == "", "show_id", "blank_key",
                  "show_id is blank; row skipped")
    dup_mask = work.duplicated("show_id", keep="first")
    summary["duplicate_key_rows"] = int(dup_mask.sum())
    work = reject(work, dup_mask, "show_id", "duplicate_key",
                  "Repeated show_id; first occurrence kept")
    work = reject(work, ~work["type"].isin(list(VALID_TYPES)), "type",
                  "invalid_type", "Type must be Movie or TV Show; row skipped")
    work = reject(work, work["title"] == "", "title", "missing_title",
                  "Title is blank; row skipped")
    work = work.assign(year_n=pd.to_numeric(work["release_year"], errors="coerce"))
    work = reject(work, work["year_n"].isna() | (work["year_n"] < 1900) | (work["year_n"] > 2100),
                  "release_year", "invalid_year", "Release year missing/invalid; row skipped")

    # dates: 'September 25, 2021' (some have leading spaces -> already stripped)
    d = work["date_added"]
    parsed = pd.to_datetime(d.mask(d == ""), format="%B %d, %Y", errors="coerce")
    for r, p, raw in zip(work.itertuples(index=False), parsed, d):
        if raw == "":
            add(r.row_no, r.show_id, "date_added", "missing_value", "date_added is blank; stored as NULL")
        elif pd.isna(p):
            add(r.row_no, r.show_id, "date_added", "bad_date", "Cannot parse '%s'; stored as NULL" % raw)

    # rating / duration (a few rows have the runtime typed into the rating column)
    rating = work["rating"].copy()
    duration = work["duration"].copy()
    moved = rating.str.match(DUR_PATTERN, case=False) & (duration == "")
    for r, val in zip(work[moved].itertuples(index=False), rating[moved]):
        add(r.row_no, r.show_id, "rating", "misplaced_value",
            "rating column held '%s'; moved to duration" % val)
    duration = duration.where(~moved, rating)
    rating = rating.where(~moved, "")

    ext = duration.str.extract(DUR_PATTERN, flags=re.I)
    dur_val = pd.to_numeric(ext[0], errors="coerce")
    unit = ext[1].fillna("").str.lower()
    for r, dv, raw, rt in zip(work.itertuples(index=False), dur_val, duration, rating):
        if raw == "":
            add(r.row_no, r.show_id, "duration", "missing_value", "duration is blank; stored as NULL")
        elif pd.isna(dv):
            add(r.row_no, r.show_id, "duration", "bad_duration", "Cannot parse '%s'" % raw)
        if rt == "":
            add(r.row_no, r.show_id, "rating", "missing_value", "rating is blank; stored as NULL")
    for r, u, t in zip(work.itertuples(index=False), unit, work["type"]):
        if u and ((t == "Movie") != (u == "min")):
            add(r.row_no, r.show_id, "duration", "unit_mismatch",
                "Unit '%s' does not match type %s" % (u, t))

    titles = []
    for sid, typ, ttl, dt, yr, rt, dv, desc in zip(
            work["show_id"], work["type"], work["title"], parsed, work["year_n"],
            rating, dur_val, work["description"]):
        titles.append((sid, typ, ttl,
                       None if pd.isna(dt) else dt.date(),
                       int(yr), rt or None,
                       None if pd.isna(dv) else int(dv), desc or None))

    ids = list(work["show_id"])
    tc = split_multi(ids, work["country"])
    tg = split_multi(ids, work["listed_in"])
    td = split_multi(ids, work["director"])
    tcast = split_multi(ids, work["cast"])

    summary["rows_loaded"] = len(titles)
    summary["error_rows"] = (summary["rows_read"] - summary["rows_loaded"]
                             - summary["duplicate_key_rows"])
    return {
        "titles": titles,
        "ratings": sorted({t[5] for t in titles if t[5]}),
        "countries": sorted({p[1] for p in tc}),
        "genres": sorted({p[1] for p in tg}),
        "people": sorted({p[1] for p in td} | {p[1] for p in tcast}),
        "title_country": tc, "title_genre": tg,
        "title_director": td, "title_cast": tcast,
        "issues": issues, "summary": summary,
    }


# ------------------------------------------------------------------ load
def apply_schema(conn):
    with open(SCHEMA_FILE, encoding="utf-8") as f:
        lines = [l for l in f.read().splitlines() if not l.strip().startswith("--")]
    cur = conn.cursor()
    for stmt in "\n".join(lines).split(";"):
        s = stmt.strip()
        if not s or s.upper().startswith(("CREATE DATABASE", "USE ")):
            continue
        cur.execute(s)


def bulk(cur, sql, rows, size=2000):
    for i in range(0, len(rows), size):
        cur.executemany(sql, rows[i:i + size])



def load_to_mysql(conn, df, res, file_name, file_size_kb):
    cur = conn.cursor()
    s = res["summary"]
    cur.execute(
        "INSERT INTO import_log (file_name, file_size_kb, rows_read, rows_loaded, "
        "duplicate_key_rows, duplicate_full_rows, error_rows) VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (file_name, round(file_size_kb, 1), s["rows_read"], s["rows_loaded"],
         s["duplicate_key_rows"], s["duplicate_full_rows"], s["error_rows"]))
    import_id = cur.lastrowid
    bulk(cur, "INSERT INTO import_issue (import_id,row_no,show_id,column_name,issue_type,issue_detail) "
              "VALUES (%s,%s,%s,%s,%s,%s)", [(import_id,) + i for i in res["issues"]])

    # staging = untouched copy of the file
    rows = [(i + 1,) + tuple((v or None) for v in r) for i, r in enumerate(df.itertuples(index=False))]
    bulk(cur, "INSERT INTO staging_netflix (row_no,show_id,`type`,title,director,cast_members,"
              "country,date_added,release_year,rating,duration,listed_in,description) "
              "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", rows)

    # lookups
    bulk(cur, "INSERT INTO content_type (type_name, duration_unit) VALUES (%s,%s)",
         list(VALID_TYPES.items()))
    bulk(cur, "INSERT INTO rating (rating_code) VALUES (%s)", [(r,) for r in res["ratings"]])
    bulk(cur, "INSERT INTO country (country_name) VALUES (%s)", [(c,) for c in res["countries"]])
    bulk(cur, "INSERT INTO genre (genre_name) VALUES (%s)", [(g,) for g in res["genres"]])
    bulk(cur, "INSERT INTO person (person_name) VALUES (%s)", [(p,) for p in res["people"]])
    cur.execute("SELECT type_id, type_name FROM content_type"); types = {n: i for i, n in cur.fetchall()}
    cur.execute("SELECT rating_id, rating_code FROM rating");   ratings = {n: i for i, n in cur.fetchall()}
    cur.execute("SELECT country_id, country_name FROM country"); countries = {n: i for i, n in cur.fetchall()}
    cur.execute("SELECT genre_id, genre_name FROM genre");       genres = {n: i for i, n in cur.fetchall()}
    cur.execute("SELECT person_id, person_name FROM person");    people = {n: i for i, n in cur.fetchall()}

    bulk(cur, "INSERT INTO titles (show_id,type_id,title,date_added,release_year,rating_id,"
              "duration_value,description) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
         [(t[0], types[t[1]], t[2], t[3], t[4], ratings.get(t[5]), t[6], t[7]) for t in res["titles"]])
    bulk(cur, "INSERT INTO title_country (show_id,country_id) VALUES (%s,%s)",
         [(a, countries[b]) for a, b in res["title_country"]])
    bulk(cur, "INSERT INTO title_genre (show_id,genre_id) VALUES (%s,%s)",
         [(a, genres[b]) for a, b in res["title_genre"]])
    bulk(cur, "INSERT INTO title_director (show_id,person_id) VALUES (%s,%s)",
         [(a, people[b]) for a, b in res["title_director"]])
    bulk(cur, "INSERT INTO title_cast (show_id,person_id) VALUES (%s,%s)",
         [(a, people[b]) for a, b in res["title_cast"]])


def run_import(path, source_url=None):
    """Full pipeline: file -> clean -> (re)create schema -> load. Returns summary dict."""
    df = read_dataset(path)
    res = clean_dataset(df)
    root = connect(database=False)
    root.cursor().execute("CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4" % DB_NAME)
    root.close()
    conn = connect()
    try:
        apply_schema(conn)
        load_to_mysql(conn, df, res, os.path.basename(path), os.path.getsize(path) / 1024)
        if source_url:
            conn.cursor().execute("UPDATE dataset_info SET source_url=%s WHERE info_id=1", (source_url,))
    finally:
        conn.close()
    out = dict(res["summary"])
    out.update({"titles": len(res["titles"]), "countries": len(res["countries"]),
                "genres": len(res["genres"]), "people": len(res["people"]),
                "issues": len(res["issues"])})
    return out
