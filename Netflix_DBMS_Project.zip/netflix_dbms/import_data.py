"""Command-line import:  python import_data.py data/netflix_titles.csv
Re-running it rebuilds the normalized tables from scratch (reproducible)."""
import argparse
from config import DEFAULT_CSV
from etl import run_import

p = argparse.ArgumentParser(description="Import the Netflix CSV into MySQL")
p.add_argument("csv", nargs="?", default=DEFAULT_CSV, help="path to netflix_titles.csv")
p.add_argument("--source-url", default="https://www.kaggle.com/datasets/shivamb/netflix-shows")
a = p.parse_args()
print("Importing", a.csv, "...")
for k, v in run_import(a.csv, a.source_url).items():
    print("  %-22s %s" % (k, v))
print("Done. Now run:  python app.py")
