-- 10 required reports (filters removed). Run in MySQL Workbench after importing.
USE netflix_dbms;

-- Report 1: Movies versus TV shows
-- Technique: GROUP BY, COUNT (+ window SUM() OVER)
SELECT ct.type_name AS content_type,
       COUNT(*) AS title_count,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS percentage
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
WHERE 1=1
GROUP BY ct.type_name
ORDER BY title_count DESC;

-- Report 2: Titles added by year
-- Technique: YEAR(), GROUP BY, COUNT
SELECT YEAR(t.date_added) AS year_added,
       COUNT(*) AS title_count
FROM titles t
WHERE t.date_added IS NOT NULL
GROUP BY YEAR(t.date_added)
ORDER BY year_added;

-- Report 3: Top 10 contributing countries
-- Technique: JOIN bridge table, COUNT(DISTINCT), ORDER BY, LIMIT
SELECT c.country_name,
       COUNT(DISTINCT t.show_id) AS title_count
FROM titles t
JOIN title_country tc ON tc.show_id = t.show_id
JOIN country c        ON c.country_id = tc.country_id
WHERE 1=1
GROUP BY c.country_id, c.country_name
ORDER BY title_count DESC, c.country_name
LIMIT 10;

-- Report 4: Catalogue by maturity rating
-- Technique: LEFT JOIN, COALESCE, GROUP BY, COUNT
SELECT COALESCE(r.rating_code, 'Not rated') AS maturity_rating,
       COUNT(*) AS title_count
FROM titles t
LEFT JOIN rating r ON r.rating_id = t.rating_id
WHERE 1=1
GROUP BY maturity_rating
ORDER BY title_count DESC;

-- Report 5: Top genres
-- Technique: VIEW (vw_title_genre), JOIN, COUNT(DISTINCT), LIMIT
SELECT vg.genre_name,
       COUNT(DISTINCT t.show_id) AS title_count
FROM titles t
JOIN vw_title_genre vg ON vg.show_id = t.show_id
WHERE 1=1
GROUP BY vg.genre_id, vg.genre_name
ORDER BY title_count DESC, vg.genre_name
LIMIT 10;

-- Report 6: Most common release decades
-- Technique: CASE, GROUP BY, ORDER BY
SELECT CASE WHEN t.release_year < 1980 THEN 'Before 1980'
            WHEN t.release_year < 1990 THEN '1980s'
            WHEN t.release_year < 2000 THEN '1990s'
            WHEN t.release_year < 2010 THEN '2000s'
            WHEN t.release_year < 2020 THEN '2010s'
            ELSE '2020s' END AS release_decade,
       COUNT(*) AS title_count
FROM titles t
WHERE 1=1
GROUP BY release_decade
ORDER BY title_count DESC;

-- Report 7: Titles added by month
-- Technique: MONTH(), MONTHNAME(), GROUP BY
SELECT MONTH(t.date_added) AS month_no,
       MONTHNAME(t.date_added) AS month_name,
       COUNT(*) AS title_count
FROM titles t
WHERE t.date_added IS NOT NULL
GROUP BY MONTH(t.date_added), MONTHNAME(t.date_added)
ORDER BY month_no;

-- Report 8: Oldest titles by type
-- Technique: WHERE, ORDER BY, derived table + ROW_NUMBER() window
SELECT ranked.type_name AS content_type,
       ranked.rn AS age_rank,
       ranked.title,
       ranked.release_year
FROM (SELECT ct.type_name, t.title, t.release_year,
             ROW_NUMBER() OVER (PARTITION BY ct.type_name
                                ORDER BY t.release_year, t.title) AS rn
      FROM titles t
      JOIN content_type ct ON ct.type_id = t.type_id
      WHERE 1=1) ranked
WHERE ranked.rn <= 10
ORDER BY ranked.type_name, ranked.rn;

-- Report 9: Countries above average title count
-- Technique: CTE, HAVING, scalar comparison
WITH country_counts AS (
    SELECT c.country_name, COUNT(DISTINCT t.show_id) AS title_count
    FROM titles t
    JOIN title_country tc ON tc.show_id = t.show_id
    JOIN country c        ON c.country_id = tc.country_id
    WHERE 1=1
    GROUP BY c.country_id, c.country_name
), avg_count AS (
    SELECT AVG(title_count) AS avg_titles FROM country_counts
)
SELECT cc.country_name, cc.title_count, ROUND(a.avg_titles, 1) AS average_titles
FROM country_counts cc
CROSS JOIN avg_count a
GROUP BY cc.country_name, cc.title_count, a.avg_titles
HAVING cc.title_count > a.avg_titles
ORDER BY cc.title_count DESC;

-- Report 10: Movie vs TV show growth by year
-- Technique: Conditional aggregation (SUM + CASE), GROUP BY
SELECT YEAR(t.date_added) AS year_added,
       SUM(CASE WHEN ct.type_name = 'Movie'   THEN 1 ELSE 0 END) AS movies,
       SUM(CASE WHEN ct.type_name = 'TV Show' THEN 1 ELSE 0 END) AS tv_shows,
       COUNT(*) AS total
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
WHERE t.date_added IS NOT NULL
GROUP BY YEAR(t.date_added)
ORDER BY year_added;
