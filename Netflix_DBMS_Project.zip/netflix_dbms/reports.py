"""The 10 required SQL reports (Team 5 - Streaming Catalogue & Content Trends).
Every query uses the alias  t  for the titles table and contains the marker {flt}
once. build_filters() turns the dashboard filters into extra AND conditions."""

FILTER_FIELDS = ["type", "rating", "year_from", "year_to", "country", "genre"]


def build_filters(args):
    c, p = [], []
    if args.get("type"):
        c.append("t.type_id = (SELECT type_id FROM content_type WHERE type_name = %s)")
        p.append(args["type"])
    if args.get("rating"):
        c.append("t.rating_id = (SELECT rating_id FROM rating WHERE rating_code = %s)")
        p.append(args["rating"])
    if str(args.get("year_from", "")).isdigit():
        c.append("t.release_year >= %s"); p.append(int(args["year_from"]))
    if str(args.get("year_to", "")).isdigit():
        c.append("t.release_year <= %s"); p.append(int(args["year_to"]))
    if args.get("country"):
        c.append("EXISTS (SELECT 1 FROM title_country fc JOIN country fcn ON fcn.country_id = fc.country_id "
                 "WHERE fc.show_id = t.show_id AND fcn.country_name = %s)")
        p.append(args["country"])
    if args.get("genre"):
        c.append("EXISTS (SELECT 1 FROM title_genre fg JOIN genre fgn ON fgn.genre_id = fg.genre_id "
                 "WHERE fg.show_id = t.show_id AND fgn.genre_name = %s)")
        p.append(args["genre"])
    return ("".join(" AND " + x for x in c), p)


REPORTS = [
 dict(id=1, name="Movies versus TV shows", technique="GROUP BY, COUNT (+ window SUM() OVER)",
      chart="doughnut", label="content_type", values=["title_count"],
      insight="Shows how the catalogue is split between movies and TV shows.",
      sql="""SELECT ct.type_name AS content_type,
       COUNT(*) AS title_count,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS percentage
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
WHERE 1=1 {flt}
GROUP BY ct.type_name
ORDER BY title_count DESC"""),
 dict(id=2, name="Titles added by year", technique="YEAR(), GROUP BY, COUNT",
      chart="line", label="year_added", values=["title_count"],
      insight="Shows how quickly Netflix added titles each year (titles with a date_added only).",
      sql="""SELECT YEAR(t.date_added) AS year_added,
       COUNT(*) AS title_count
FROM titles t
WHERE t.date_added IS NOT NULL {flt}
GROUP BY YEAR(t.date_added)
ORDER BY year_added"""),
 dict(id=3, name="Top 10 contributing countries", technique="JOIN bridge table, COUNT(DISTINCT), ORDER BY, LIMIT",
      chart="hbar", label="country_name", values=["title_count"],
      insight="Countries credited on the most titles; one title can count for several countries.",
      sql="""SELECT c.country_name,
       COUNT(DISTINCT t.show_id) AS title_count
FROM titles t
JOIN title_country tc ON tc.show_id = t.show_id
JOIN country c        ON c.country_id = tc.country_id
WHERE 1=1 {flt}
GROUP BY c.country_id, c.country_name
ORDER BY title_count DESC, c.country_name
LIMIT 10"""),
 dict(id=4, name="Catalogue by maturity rating", technique="LEFT JOIN, COALESCE, GROUP BY, COUNT",
      chart="bar", label="maturity_rating", values=["title_count"],
      insight="Shows which audience age-groups the catalogue targets; blank ratings are grouped as Not rated.",
      sql="""SELECT COALESCE(r.rating_code, 'Not rated') AS maturity_rating,
       COUNT(*) AS title_count
FROM titles t
LEFT JOIN rating r ON r.rating_id = t.rating_id
WHERE 1=1 {flt}
GROUP BY maturity_rating
ORDER BY title_count DESC"""),
 dict(id=5, name="Top genres", technique="VIEW (vw_title_genre), JOIN, COUNT(DISTINCT), LIMIT",
      chart="bar", label="genre_name", values=["title_count"],
      insight="Most common genre tags; a title can carry several genres.",
      sql="""SELECT vg.genre_name,
       COUNT(DISTINCT t.show_id) AS title_count
FROM titles t
JOIN vw_title_genre vg ON vg.show_id = t.show_id
WHERE 1=1 {flt}
GROUP BY vg.genre_id, vg.genre_name
ORDER BY title_count DESC, vg.genre_name
LIMIT 10"""),
 dict(id=6, name="Most common release decades", technique="CASE, GROUP BY, ORDER BY",
      chart="column", label="release_decade", values=["title_count"],
      insight="Shows whether the catalogue is dominated by recent or older productions.",
      sql="""SELECT CASE WHEN t.release_year < 1980 THEN 'Before 1980'
            WHEN t.release_year < 1990 THEN '1980s'
            WHEN t.release_year < 2000 THEN '1990s'
            WHEN t.release_year < 2010 THEN '2000s'
            WHEN t.release_year < 2020 THEN '2010s'
            ELSE '2020s' END AS release_decade,
       COUNT(*) AS title_count
FROM titles t
WHERE 1=1 {flt}
GROUP BY release_decade
ORDER BY title_count DESC"""),
 dict(id=7, name="Titles added by month", technique="MONTH(), MONTHNAME(), GROUP BY",
      chart="line", label="month_name", values=["title_count"],
      insight="Reveals seasonality: which calendar months receive the most new titles.",
      sql="""SELECT MONTH(t.date_added) AS month_no,
       MONTHNAME(t.date_added) AS month_name,
       COUNT(*) AS title_count
FROM titles t
WHERE t.date_added IS NOT NULL {flt}
GROUP BY MONTH(t.date_added), MONTHNAME(t.date_added)
ORDER BY month_no"""),
 dict(id=8, name="Oldest titles by type", technique="WHERE, ORDER BY, derived table + ROW_NUMBER() window",
      chart="table", label="title", values=[],
      insight="The 10 oldest movies and 10 oldest TV shows by release year.",
      sql="""SELECT ranked.type_name AS content_type,
       ranked.rn AS age_rank,
       ranked.title,
       ranked.release_year
FROM (SELECT ct.type_name, t.title, t.release_year,
             ROW_NUMBER() OVER (PARTITION BY ct.type_name
                                ORDER BY t.release_year, t.title) AS rn
      FROM titles t
      JOIN content_type ct ON ct.type_id = t.type_id
      WHERE 1=1 {flt}) ranked
WHERE ranked.rn <= 10
ORDER BY ranked.type_name, ranked.rn"""),
 dict(id=9, name="Countries above average title count", technique="CTE, HAVING, scalar comparison",
      chart="table", label="country_name", values=["title_count"],
      insight="Countries that contribute more titles than the average country.",
      sql="""WITH country_counts AS (
    SELECT c.country_name, COUNT(DISTINCT t.show_id) AS title_count
    FROM titles t
    JOIN title_country tc ON tc.show_id = t.show_id
    JOIN country c        ON c.country_id = tc.country_id
    WHERE 1=1 {flt}
    GROUP BY c.country_id, c.country_name
), avg_count AS (
    SELECT AVG(title_count) AS avg_titles FROM country_counts
)
SELECT cc.country_name, cc.title_count, ROUND(a.avg_titles, 1) AS average_titles
FROM country_counts cc
CROSS JOIN avg_count a
GROUP BY cc.country_name, cc.title_count, a.avg_titles
HAVING cc.title_count > a.avg_titles
ORDER BY cc.title_count DESC"""),
 dict(id=10, name="Movie vs TV show growth by year", technique="Conditional aggregation (SUM + CASE), GROUP BY",
      chart="stacked", label="year_added", values=["movies", "tv_shows"],
      insight="Compares how movie and TV-show additions grew year by year.",
      sql="""SELECT YEAR(t.date_added) AS year_added,
       SUM(CASE WHEN ct.type_name = 'Movie'   THEN 1 ELSE 0 END) AS movies,
       SUM(CASE WHEN ct.type_name = 'TV Show' THEN 1 ELSE 0 END) AS tv_shows,
       COUNT(*) AS total
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
WHERE t.date_added IS NOT NULL {flt}
GROUP BY YEAR(t.date_added)
ORDER BY year_added"""),
]

# extra dashboard-only charts (histogram + directors)
EXTRA = {
 "runtime": dict(name="Movie runtime distribution", chart="histogram", label="runtime_band",
      values=["movie_count"],
      sql="""SELECT CASE WHEN t.duration_value < 60  THEN 'Under 60'
            WHEN t.duration_value < 90  THEN '60-89'
            WHEN t.duration_value < 120 THEN '90-119'
            WHEN t.duration_value < 150 THEN '120-149'
            ELSE '150+' END AS runtime_band,
       COUNT(*) AS movie_count,
       MIN(t.duration_value) AS band_start
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
WHERE ct.type_name = 'Movie' AND t.duration_value IS NOT NULL {flt}
GROUP BY runtime_band
ORDER BY band_start"""),
 "directors": dict(name="Top 10 directors", chart="bar", label="person_name",
      values=["title_count"],
      sql="""SELECT p.person_name, COUNT(DISTINCT t.show_id) AS title_count
FROM titles t
JOIN title_director td ON td.show_id = t.show_id
JOIN person p          ON p.person_id = td.person_id
WHERE 1=1 {flt}
GROUP BY p.person_id, p.person_name
ORDER BY title_count DESC, p.person_name
LIMIT 10"""),
}

# dashboard layout: (key, title, chart kind, report id or extra key)
DASHBOARD = [
 ("added_year",  "Titles added by year (trend)",            "line",      2),
 ("types",       "Movies vs TV shows",                       "doughnut",  1),
 ("countries",   "Top 10 countries by title count",          "hbar",      3),
 ("ratings",     "Catalogue by maturity rating",             "bar",       4),
 ("genres",      "Top 10 genres",                            "hbar",      5),
 ("decades",     "Release decades",                          "column",    6),
 ("months",      "Titles added by month (seasonality)",      "line",      7),
 ("growth",      "Movie vs TV show growth by year",          "stacked",   10),
 ("runtime",     "Movie runtime distribution (histogram)",   "histogram", "runtime"),
 ("directors",   "Top 10 directors",                         "bar",       "directors"),
]

KPI_SQL = """SELECT (SELECT COUNT(*) FROM titles) AS total_titles,
       (SELECT COUNT(*) FROM titles t JOIN content_type ct ON ct.type_id = t.type_id
         WHERE ct.type_name = 'Movie') AS movies,
       (SELECT COUNT(*) FROM titles t JOIN content_type ct ON ct.type_id = t.type_id
         WHERE ct.type_name = 'TV Show') AS tv_shows,
       (SELECT COUNT(*) FROM country) AS countries,
       (SELECT COUNT(*) FROM genre) AS genres,
       (SELECT COUNT(*) FROM person) AS people,
       (SELECT MAX(date_added) FROM titles) AS latest_added"""


def get_report(rid):
    return next((r for r in REPORTS if r["id"] == rid), None)


def render(spec, args):
    flt, params = build_filters(args)
    return spec["sql"].replace("{flt}", flt), params
