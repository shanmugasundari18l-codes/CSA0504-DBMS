-- =====================================================================
-- Netflix Catalogue DBMS  |  MySQL 8.x  |  Team 5 capstone
-- Raw CSV -> staging_netflix -> normalized (3NF) tables
-- Run order: this file, then import_data.py (or just run import_data.py)
-- =====================================================================
CREATE DATABASE IF NOT EXISTS netflix_dbms CHARACTER SET utf8mb4;
USE netflix_dbms;

SET FOREIGN_KEY_CHECKS = 0;
DROP VIEW  IF EXISTS vw_title_details;
DROP VIEW  IF EXISTS vw_title_genre;
DROP TABLE IF EXISTS title_cast;
DROP TABLE IF EXISTS title_director;
DROP TABLE IF EXISTS title_genre;
DROP TABLE IF EXISTS title_country;
DROP TABLE IF EXISTS titles;
DROP TABLE IF EXISTS person;
DROP TABLE IF EXISTS genre;
DROP TABLE IF EXISTS country;
DROP TABLE IF EXISTS rating;
DROP TABLE IF EXISTS content_type;
DROP TABLE IF EXISTS staging_netflix;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- 1. STAGING: exact copy of the CSV (all text) ----------
CREATE TABLE staging_netflix (
    row_no        INT UNSIGNED NOT NULL,
    show_id       VARCHAR(20),
    `type`        VARCHAR(50),
    title         VARCHAR(500),
    director      TEXT,
    cast_members  TEXT,
    country       TEXT,
    date_added    VARCHAR(50),
    release_year  VARCHAR(10),
    rating        VARCHAR(30),
    duration      VARCHAR(30),
    listed_in     TEXT,
    description   TEXT,
    PRIMARY KEY (row_no)
) ENGINE=InnoDB;

-- ---------- 2. LOOKUP TABLES ----------
CREATE TABLE content_type (
    type_id        TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    type_name      VARCHAR(20) NOT NULL,
    duration_unit  VARCHAR(10) NOT NULL,
    PRIMARY KEY (type_id),
    UNIQUE KEY uq_content_type_name (type_name)
) ENGINE=InnoDB;

CREATE TABLE rating (
    rating_id    SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    rating_code  VARCHAR(20) NOT NULL,
    PRIMARY KEY (rating_id),
    UNIQUE KEY uq_rating_code (rating_code)
) ENGINE=InnoDB;

CREATE TABLE country (
    country_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    country_name  VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    PRIMARY KEY (country_id),
    UNIQUE KEY uq_country_name (country_name)
) ENGINE=InnoDB;

CREATE TABLE genre (
    genre_id    SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    genre_name  VARCHAR(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    PRIMARY KEY (genre_id),
    UNIQUE KEY uq_genre_name (genre_name)
) ENGINE=InnoDB;

CREATE TABLE person (
    person_id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    person_name  VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    PRIMARY KEY (person_id),
    UNIQUE KEY uq_person_name (person_name)
) ENGINE=InnoDB;

-- ---------- 3. MAIN ENTITY ----------
CREATE TABLE titles (
    show_id         VARCHAR(20)  NOT NULL,
    type_id         TINYINT UNSIGNED NOT NULL,
    title           VARCHAR(500) NOT NULL,
    date_added      DATE NULL,
    release_year    SMALLINT UNSIGNED NOT NULL,
    rating_id       SMALLINT UNSIGNED NULL,
    duration_value  SMALLINT UNSIGNED NULL,
    description     TEXT NULL,
    PRIMARY KEY (show_id),
    CONSTRAINT fk_titles_type   FOREIGN KEY (type_id)   REFERENCES content_type (type_id),
    CONSTRAINT fk_titles_rating FOREIGN KEY (rating_id) REFERENCES rating (rating_id),
    CONSTRAINT chk_titles_year     CHECK (release_year BETWEEN 1900 AND 2100),
    CONSTRAINT chk_titles_duration CHECK (duration_value IS NULL OR duration_value > 0),
    INDEX idx_titles_release_year (release_year),
    INDEX idx_titles_date_added (date_added),
    INDEX idx_titles_title (title(100))
) ENGINE=InnoDB;

-- ---------- 4. BRIDGE TABLES (many-to-many) ----------
CREATE TABLE title_country (
    show_id     VARCHAR(20) NOT NULL,
    country_id  INT UNSIGNED NOT NULL,
    PRIMARY KEY (show_id, country_id),
    CONSTRAINT fk_tc_title   FOREIGN KEY (show_id)    REFERENCES titles (show_id) ON DELETE CASCADE,
    CONSTRAINT fk_tc_country FOREIGN KEY (country_id) REFERENCES country (country_id),
    INDEX idx_tc_country (country_id)
) ENGINE=InnoDB;

CREATE TABLE title_genre (
    show_id   VARCHAR(20) NOT NULL,
    genre_id  SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (show_id, genre_id),
    CONSTRAINT fk_tg_title FOREIGN KEY (show_id)  REFERENCES titles (show_id) ON DELETE CASCADE,
    CONSTRAINT fk_tg_genre FOREIGN KEY (genre_id) REFERENCES genre (genre_id),
    INDEX idx_tg_genre (genre_id)
) ENGINE=InnoDB;

CREATE TABLE title_director (
    show_id    VARCHAR(20) NOT NULL,
    person_id  INT UNSIGNED NOT NULL,
    PRIMARY KEY (show_id, person_id),
    CONSTRAINT fk_td_title  FOREIGN KEY (show_id)   REFERENCES titles (show_id) ON DELETE CASCADE,
    CONSTRAINT fk_td_person FOREIGN KEY (person_id) REFERENCES person (person_id),
    INDEX idx_td_person (person_id)
) ENGINE=InnoDB;

CREATE TABLE title_cast (
    show_id    VARCHAR(20) NOT NULL,
    person_id  INT UNSIGNED NOT NULL,
    PRIMARY KEY (show_id, person_id),
    CONSTRAINT fk_tcast_title  FOREIGN KEY (show_id)   REFERENCES titles (show_id) ON DELETE CASCADE,
    CONSTRAINT fk_tcast_person FOREIGN KEY (person_id) REFERENCES person (person_id),
    INDEX idx_tcast_person (person_id)
) ENGINE=InnoDB;

-- ---------- 5. AUDIT / METADATA (kept between imports) ----------
CREATE TABLE IF NOT EXISTS import_log (
    import_id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
    file_name           VARCHAR(255) NOT NULL,
    file_size_kb        DECIMAL(10,1) NOT NULL,
    imported_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    rows_read           INT NOT NULL,
    rows_loaded         INT NOT NULL,
    duplicate_key_rows  INT NOT NULL DEFAULT 0,
    duplicate_full_rows INT NOT NULL DEFAULT 0,
    error_rows          INT NOT NULL DEFAULT 0,
    PRIMARY KEY (import_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS import_issue (
    issue_id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    import_id     INT UNSIGNED NOT NULL,
    row_no        INT NULL,
    show_id       VARCHAR(20) NULL,
    column_name   VARCHAR(50) NULL,
    issue_type    VARCHAR(40) NOT NULL,
    issue_detail  VARCHAR(255) NULL,
    PRIMARY KEY (issue_id),
    CONSTRAINT fk_issue_import FOREIGN KEY (import_id) REFERENCES import_log (import_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS dataset_info (
    info_id      TINYINT NOT NULL,
    dataset_name VARCHAR(200),
    author       VARCHAR(200),
    source_url   VARCHAR(500),
    license_note VARCHAR(300),
    description  TEXT,
    purpose      TEXT,
    PRIMARY KEY (info_id)
) ENGINE=InnoDB;

INSERT IGNORE INTO dataset_info VALUES (1,
  'Netflix Movies and TV Shows', 'Shivam Bansal (Kaggle)',
  'https://www.kaggle.com/datasets/shivamb/netflix-shows',
  'Check the licence shown on the Kaggle dataset page and note the version you downloaded',
  'Listing of movies and TV shows available on Netflix (catalogue snapshot) with type, title, director, cast, country, date added, release year, rating, duration and genres.',
  'Used to build a normalized MySQL database and an analytics dashboard on catalogue size, genres, countries, ratings and growth over time.');

-- ---------- 6. VIEWS ----------
CREATE VIEW vw_title_details AS
SELECT t.show_id, t.title, ct.type_name AS content_type, t.release_year,
       t.date_added, r.rating_code AS rating, t.duration_value,
       ct.duration_unit, t.description
FROM titles t
JOIN content_type ct ON ct.type_id = t.type_id
LEFT JOIN rating r   ON r.rating_id = t.rating_id;

CREATE VIEW vw_title_genre AS
SELECT tg.show_id, g.genre_id, g.genre_name
FROM title_genre tg
JOIN genre g ON g.genre_id = tg.genre_id;
